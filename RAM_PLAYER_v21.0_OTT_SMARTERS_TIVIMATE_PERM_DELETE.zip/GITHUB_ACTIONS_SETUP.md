# GitHub Actions Mobile Build Setup — StreamX Media3 Pro v18.1

## Mobile se APK Build karne ke Steps (Bina PC/Laptop ke)

1. Apne phone ke Chrome browser mein GitHub repository kholen.
2. Is project ki **ZIP file (`StreamX_Media3_Pro_v18.1_Next_Gen_Ultra_Extreme_Correct_VOD_Edition.zip`)** ko seedhe repository root mein upload kar dein (ya unzip karke files upload karein — workflow dono तरीकों ko support karta hai aur latest `.zip` ko automatically extract kar leta hai).
3. Repository mein `.github/workflows/build_apk.yml` mein workflow YAML save karein.
4. **Actions** tab mein jayein -> **StreamX Media3 Pro v18.1 Next-Gen Ultra Extreme - Build & Verify APK** select karein -> **Run workflow** dabayein.
5. Build green hone ke baad **Artifacts** section se **`StreamX-Media3-Pro-v18.1-Next-Gen-Ultra-Extreme-Release`** download karein. Iske andar aapko `StreamX-Media3-Pro-v18.1-Next-Gen-Ultra-Extreme-512MB.apk` milegi jo 512MB RAM TV aur mobile dono par seedhe install hogi.

## Release Signing Note
Agar aapne repository secrets (`ANDROID_KEYSTORE_BASE64`, `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS`, `ANDROID_KEY_PASSWORD`) set kiye hain, toh APK aapke persistent release key se sign hogi. Agar secrets set nahi hain, toh `app/build.gradle.kts` automatically installable debug signing key use karta hai taaki APK bina kisi error ke TV par install ho sake.
